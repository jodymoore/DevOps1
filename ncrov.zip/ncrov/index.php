
<?php
    // configuration
require 'aws-autoloader.php';

header("Location: ncrov/public/index.php");
die();
   
?> 
