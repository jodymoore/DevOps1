
<?php
    // configuration
require 'aws-autoloader.php';

header("Location: public/index.php");
die();
   
?> 
