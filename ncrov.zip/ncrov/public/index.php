<?php
    // configuration
   require("../includes/config.php");

   render("select_form.php");
?> 