<?php
    // configuration
   require("../includes/config.php");

   render("hud2_form.php");
?> 