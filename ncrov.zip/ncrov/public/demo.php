<?php
    // configuration
   require("../includes/config.php");

   render("demo_form.php");
?> 