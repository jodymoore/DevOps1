<?php
    // configuration
   require("../includes/config.php");

   render("hud_form.php");
?> 