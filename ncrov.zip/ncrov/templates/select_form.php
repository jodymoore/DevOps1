<div id="middle">
	<form action="select.php" method="post">
	<a  align="center"><img id="img2"alt="Rover" width="500" height="400" src="/public/img/rover_img5.jpg"/></a>   
     <fieldset>      
       <ul  class="nav nav-pills "> 
           <div>
               <li><a href="demo.php">Demo</a></li>
           </div>                  
           <li><a href="hud.php">With WiFi Camera</a></li> 
           <li><a href="hud2.php">With Out WiFi Camera</a></li>         
       </ul>
            
    </fieldset>
    </form>
</div>