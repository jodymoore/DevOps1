    <div id = "middle">
        <form action="login.php" method="post">
            <fieldset>
                <div class="form-group">
                    <input class="form-control" name="username" placeholder="Username" type="text"/>
                </div>
                <div class="form-group">
                    <input class="form-control" name="password" placeholder="Password" type="password"/>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-default">Log In</button>
                </div>
            </fieldset>
        </form>
        <div>
            <a href="register.php"><h4>REGISTER</a> for an account</h4>
                    </div>
    </div>
</div>
