<div id = "middle">
    <form action="demo.php" method="post">
        <div id="text">
            <p><h4>Rover1 is a precursor to an NCROV Network Controlled Remote Operated Vehicle.</h4><p>
            <p><h4>It is equipped with an onboard processor, Arduino Yun, that  can easily accomodate</h4><p>
            <p><h4>an upscaled version of the rover ( i.e larger power frame ,suspension ). Rover1 is</h4><p> 
            <p><h4>operated via the web based GUI implemented on this site. Equipped with onboard</h4><p> 
            <p><h4>video, rover can be manuevered anywhere the network signal can be transmitted.</h4><p>
            <p><h4>Implemented clientside with HTML, CSS, SQL, javascript, and jQuery. The Rover1</h4></p>
            <p><h4>onboard processor, Arduino Yun, is setup using a server executed in C++.</h4></p>
        </div>
        <br>
    <iframe align="center" width="400" height="300" src="//www.youtube.com/embed/DeQBBpo8d54?list=UUjQu2JJvpJ5lREwdfoz-EaQ" frameborder="5" allowfullscreen></iframe>
    <iframe align= "center" width="400" height="300" src="////www.youtube.com/embed/APebLwRIt48" frameborder="5" allowfullscreen></iframe>

    </form>
</div>
<ul  class="nav nav-pills "> 
    <div>
        <li><a href="select.php">Back</a></li> 
    </div>
</ul>